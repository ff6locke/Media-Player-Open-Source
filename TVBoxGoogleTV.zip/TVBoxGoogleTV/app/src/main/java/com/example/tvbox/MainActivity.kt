package com.example.tvbox

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import coil.load
import java.net.HttpURLConnection
import java.net.URL

private const val ALL = "全部"

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }
    private val all = mutableListOf<Channel>()
    private val shown = mutableListOf<Channel>()
    private val groups = mutableListOf<String>()
    private var selectedGroup = ALL
    private var query = ""

    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var categoryList: RecyclerView
    private lateinit var posterList: RecyclerView
    private val categoryAdapter = CategoryAdapter()
    private val posterAdapter = PosterAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        search = findViewById(R.id.search)
        categoryList = findViewById(R.id.categoryList)
        posterList = findViewById(R.id.posterList)

        categoryList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        categoryList.adapter = categoryAdapter
        posterList.layoutManager = GridLayoutManager(this, 5)
        posterList.adapter = posterAdapter

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                query = s?.toString()?.trim().orEmpty()
                refresh()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        findViewById<Button>(R.id.settingsButton).setOnClickListener { showSettings() }

        val saved = prefs.getString("source", "").orEmpty()
        if (saved.isEmpty()) status.text = getString(R.string.no_source) else loadSource(saved)
    }

    private fun showSettings() {
        val input = EditText(this).apply {
            hint = getString(R.string.source_hint)
            setText(prefs.getString("source", ""))
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.settings)
            .setView(input)
            .setPositiveButton(R.string.load) { _, _ ->
                val url = input.text.toString().trim()
                prefs.edit().putString("source", url).apply()
                if (url.isEmpty()) status.text = getString(R.string.no_source) else loadSource(url)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun loadSource(url: String) {
        status.text = getString(R.string.loading)
        Thread {
            val text = try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 15000
                conn.inputStream.bufferedReader().use { it.readText() }
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                if (text == null) {
                    status.text = getString(R.string.load_failed)
                } else {
                    all.clear()
                    all.addAll(M3UParser.parse(text))
                    groups.clear()
                    groups.add(ALL)
                    groups.addAll(all.map { it.group }.distinct())
                    selectedGroup = ALL
                    categoryAdapter.notifyDataSetChanged()
                    refresh()
                }
            }
        }.start()
    }

    private fun refresh() {
        shown.clear()
        shown.addAll(all.filter {
            (selectedGroup == ALL || it.group == selectedGroup) &&
                (query.isEmpty() || it.name.contains(query, ignoreCase = true))
        })
        posterAdapter.notifyDataSetChanged()
        status.text = if (all.isEmpty()) getString(R.string.no_source)
        else getString(R.string.loaded_count, shown.size)
    }

    private fun dp(v: Int) = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    inner class CategoryAdapter : RecyclerView.Adapter<CategoryAdapter.VH>() {
        inner class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val tv = TextView(parent.context).apply {
                textSize = 16f
                setPadding(dp(18), dp(10), dp(18), dp(10))
                isFocusable = true
                layoutParams = ViewGroup.MarginLayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(10) }
            }
            return VH(tv)
        }

        override fun getItemCount() = groups.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val name = groups[position]
            val selected = name == selectedGroup
            holder.tv.text = name
            holder.tv.setTextColor(if (selected) Color.WHITE else Color.parseColor("#AAAAAA"))
            holder.tv.setBackgroundColor(
                if (selected) Color.parseColor("#FF6A00") else Color.parseColor("#22222A")
            )
            holder.tv.setOnClickListener {
                selectedGroup = name
                categoryAdapter.notifyDataSetChanged()
                refresh()
            }
        }
    }

    inner class PosterAdapter : RecyclerView.Adapter<PosterAdapter.VH>() {
        inner class VH(view: android.view.View) : RecyclerView.ViewHolder(view) {
            val image: android.widget.ImageView = view.findViewById(R.id.posterImage)
            val title: TextView = view.findViewById(R.id.posterTitle)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_poster, parent, false)
            return VH(v)
        }

        override fun getItemCount() = shown.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val ch = shown[position]
            holder.title.text = ch.name
            if (ch.logo != null) holder.image.load(ch.logo) else holder.image.setImageDrawable(null)
            holder.itemView.setOnClickListener {
                startActivity(
                    Intent(this@MainActivity, PlayerActivity::class.java)
                        .putExtra("url", ch.url)
                        .putExtra("name", ch.name)
                )
            }
        }
    }
}
