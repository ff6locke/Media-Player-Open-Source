package com.example.tvbox

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("settings", Context.MODE_PRIVATE) }
    private lateinit var sourceInput: EditText
    private lateinit var status: TextView
    private lateinit var list: RecyclerView
    private val channels = mutableListOf<Channel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sourceInput = findViewById(R.id.sourceInput)
        status = findViewById(R.id.status)
        list = findViewById(R.id.channelList)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = ChannelAdapter()

        sourceInput.setText(prefs.getString("source", ""))

        findViewById<Button>(R.id.loadButton).setOnClickListener {
            val url = sourceInput.text.toString().trim()
            prefs.edit().putString("source", url).apply()
            if (url.isEmpty()) {
                status.text = getString(R.string.no_source)
            } else {
                loadSource(url)
            }
        }
    }

    private fun loadSource(url: String) {
        status.text = getString(R.string.loading)
        Thread {
            val result = try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 15000
                conn.inputStream.bufferedReader().use { it.readText() }
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                if (result == null) {
                    status.text = getString(R.string.load_failed)
                } else {
                    channels.clear()
                    channels.addAll(M3UParser.parse(result))
                    list.adapter?.notifyDataSetChanged()
                    status.text = getString(R.string.loaded_count, channels.size)
                }
            }
        }.start()
    }

    inner class ChannelAdapter : RecyclerView.Adapter<ChannelAdapter.VH>() {
        inner class VH(val view: View) : RecyclerView.ViewHolder(view)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
            v.isFocusable = true
            return VH(v)
        }

        override fun getItemCount() = channels.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val ch = channels[position]
            holder.view.findViewById<TextView>(R.id.channelName).text = ch.name
            holder.view.findViewById<TextView>(R.id.channelGroup).text = ch.group
            holder.view.setOnClickListener {
                startActivity(
                    Intent(this@MainActivity, PlayerActivity::class.java)
                        .putExtra("url", ch.url)
                        .putExtra("name", ch.name)
                )
            }
        }
    }
}
