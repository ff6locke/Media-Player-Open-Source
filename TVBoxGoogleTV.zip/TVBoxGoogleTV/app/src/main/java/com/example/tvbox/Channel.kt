package com.example.tvbox

data class Channel(val group: String, val name: String, val url: String, val logo: String?)

object M3UParser {
    // Parses M3U/M3U8 playlists, reading group-title and tvg-logo from #EXTINF lines.
    fun parse(text: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var pendingName: String? = null
        var pendingGroup = "其他"
        var pendingLogo: String? = null
        for (raw in text.lines()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> {
                    pendingName = line.substringAfterLast(",").trim()
                    pendingGroup = attr(line, "group-title")?.ifBlank { null } ?: "其他"
                    pendingLogo = attr(line, "tvg-logo")?.ifBlank { null }
                }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    result.add(Channel(pendingGroup, pendingName ?: line, line, pendingLogo))
                    pendingName = null
                    pendingGroup = "其他"
                    pendingLogo = null
                }
            }
        }
        return result
    }

    private fun attr(line: String, key: String): String? =
        Regex("$key=\"([^\"]*)\"").find(line)?.groupValues?.get(1)
}
