package com.example.tvbox

data class Channel(val group: String, val name: String, val url: String)

object M3UParser {
    // Parses an M3U/M3U8 playlist. Supports #EXTINF lines with group-title.
    fun parse(text: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var pendingName: String? = null
        var pendingGroup = "Other"
        for (raw in text.lines()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> {
                    pendingName = line.substringAfterLast(",").trim()
                    pendingGroup = Regex("group-title=\"([^\"]*)\"")
                        .find(line)?.groupValues?.get(1)?.ifBlank { "Other" } ?: "Other"
                }
                line.isNotEmpty() && !line.startsWith("#") -> {
                    result.add(Channel(pendingGroup, pendingName ?: line, line))
                    pendingName = null
                    pendingGroup = "Other"
                }
            }
        }
        return result
    }
}
