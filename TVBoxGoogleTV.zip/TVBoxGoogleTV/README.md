# TVBox for Google TV

A minimal Google TV / Android app. It starts with no sources. You enter your own M3U playlist URL, load it, and play channels with ExoPlayer.

## Build

1. Open this folder in Android Studio (Ladybug or newer).
2. Let Gradle sync. Android Studio creates the Gradle wrapper automatically.
3. Build > Build APK(s), or Run on a Google TV device.

## Push to GitHub

    git init
    git add .
    git commit -m "Initial commit"
    git branch -M main
    git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
    git push -u origin main

## Automatic APK build

After you push to `main`, open the **Actions** tab on GitHub. The **Build APK** workflow compiles the app. Download the APK from the run's **Artifacts** section.

## Notes

- No content is bundled. Add only playlists you have the rights to use.
- Supports M3U/M3U8 playlists with optional group-title tags.
- Navigate with the remote's D-pad. Each item is focusable.
